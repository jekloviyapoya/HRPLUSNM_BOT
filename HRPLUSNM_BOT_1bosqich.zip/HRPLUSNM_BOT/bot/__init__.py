"""HRPLUSNM bot paketi."""
